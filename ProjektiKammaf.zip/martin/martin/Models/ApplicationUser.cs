using Microsoft.AspNetCore.Identity;

namespace SushiRestaurant.Models
{
    public class ApplicationUser : IdentityUser
    {
        // You can add custom properties here, such as user preferences, order history, etc.
    }
}
