﻿document.addEventListener("DOMContentLoaded", async () => {
    await initializeMenu();
    renderCart();

    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") document.body.classList.add("light-theme");
});

let cart = JSON.parse(localStorage.getItem("cart")) || [];

async function initializeMenu() {
    try {
        const response = await fetch("http://localhost:5133/api/menu");
        if (!response.ok) throw new Error(HTTP error! Status: ${ response.status });

        const menuData = await response.json();
        renderMenu(menuData);
    } catch (error) {
        console.error("❌ Failed to load menu:", error);
    }
}



function renderMenu(menuData) {
    const menuContainer = document.getElementById("menu-container");
    menuContainer.innerHTML = "";

    Object.keys(menuData).forEach(category => {
        const categoryDiv = document.createElement("div");
        categoryDiv.classList.add("menu-category");
        categoryDiv.innerHTML = <h2>${category.toUpperCase()}</h2>;

        menuData[category].forEach(item => {
            const itemDiv = document.createElement("div");
            itemDiv.classList.add("menu-item");
            itemDiv.innerHTML = `
              <div class="menu-item-left">
                  <img src="${item.image}" alt="${item.name}">
              </div>
              <div class="menu-item-right">
                  <div class="menu-item-header">
                      <span class="menu-item-name">${item.name}</span>
                      <span class="menu-item-price">$${item.price.toFixed(2)}</span>
                  </div>
                  <div class="menu-item-footer">
                      <span class="menu-item-description">${item.description}</span>
                      <button class="menu-item-add-to-cart" onclick="addToCart('${item.id}', '${item.name}', ${item.price})">+</button>
                  </div>
              </div>
          `;
            categoryDiv.appendChild(itemDiv);
        });
        menuContainer.appendChild(categoryDiv);
    });
}

// Setup category buttons for smooth scrolling and active states
function setupCategoryButtons() {
    const categoryButtons = document.querySelectorAll('.btn-category');
    categoryButtons.forEach((button) => {
        button.addEventListener('click', () => {
            // Remove active state from all buttons
            categoryButtons.forEach((btn) => btn.classList.remove('active'));

            // Add active state to the clicked button
            button.classList.add('active');

            // Get the target category ID from the button
            const targetCategory = button.getAttribute('data-target');
            scrollToCategory(targetCategory);
        });
    });
}


function scrollToCategory(id) {
    const correctedId = id.replace("-", " "); // Convert "special-rolls" → "special rolls"
    const categoryElement = document.getElementById(correctedId);

    if (categoryElement) {
        categoryElement.scrollIntoView({ behavior: "smooth", block: "start" });

        document.querySelectorAll(".btn-category").forEach(btn => btn.classList.remove("active"));
        const targetBtn = document.querySelector([onclick = "scrollToCategory('${id}')"]);
        if (targetBtn) targetBtn.classList.add("active");
    } else {
        console.error(❌ Category "${id}" not found!);
    }
}


// Ensure category buttons update when scrolling manually
window.addEventListener("scroll", () => {
    const sections = document.querySelectorAll(".menu-category");
    let currentSection = "";

    sections.forEach((section) => {
        const rect = section.getBoundingClientRect();
        if (rect.top <= 150 && rect.bottom >= 150) {
            currentSection = section.id;
        }
    });

    // Update active button
    document.querySelectorAll(".btn-category").forEach((btn) => {
        btn.classList.remove("active");
    });

    if (currentSection) {
        document.querySelector([onclick = "scrollToCategory('${currentSection}')"])?.classList.add("active");
    }
});

function addToCart(id, name, price) {
    const existingItem = cart.find(item => item.id === id);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ id, name, price, quantity: 1 });
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
}


function renderCart() {
    const cartItemsContainer = document.getElementById("cart-items");
    cartItemsContainer.innerHTML = cart.map(
        item => `
      <li class="list-group-item d-flex justify-content-between align-items-center">
          <div>${item.name} x${item.quantity}</div>
          <div>
              <span class="badge bg-primary">$${(item.price * item.quantity).toFixed(2)}</span>
              <button class="btn btn-add" onclick="incrementCartItem('${item.id}')">Add</button>
              <button class="btn btn-remove" onclick="removeFromCart('${item.id}')">Remove</button>
          </div>
      </li>`
    ).join("");

    document.getElementById("total-price").textContent = Total: $${ cart.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2) };
}

async function saveOrder(order) {
    try {
        const response = await fetch("http://localhost:5133/api/orders", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(order)
        });

        if (response.ok) {
            alert("Order placed successfully!");
            localStorage.removeItem("cart"); // Clear cart after successful order
            renderCart(); // Refresh cart UI
        } else {
            const errorData = await response.json();
            console.error("Error placing order:", errorData);
            alert("Failed to place order. Please try again.");
        }
    } catch (error) {
        console.error("Error:", error);
        alert("Error connecting to the server.");
    }
}




async function placeOrder() {
    if (cart.length === 0) {
        alert("Your cart is empty. Add items to checkout.");
        return;
    }

    const name = document.getElementById("customer-name").value.trim();
    const phone = document.getElementById("phone-number").value.trim();
    const address = document.getElementById("address").value.trim();

    if (!name || !phone || !address) {
        alert("Please fill in all the fields.");
        return;
    }

    const order = {
        name,
        phone,
        address,
        items: cart,
        total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    };

    try {
        const response = await fetch("http://localhost:5133/api/orders", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(order),
        });

        if (!response.ok) throw new Error("Failed to place order");

        alert("Order placed successfully!");
        cart = []; // ✅ Clear the cart only after success
        localStorage.removeItem("cart");
        renderCart();
    } catch (error) {
        console.error("Error placing order:", error);
        alert("Error connecting to the server.");
    }
}


function incrementCartItem(id) {
    const item = cart.find(cartItem => cartItem.id === id);
    if (item) {
        item.quantity++;
        localStorage.setItem("cart", JSON.stringify(cart));
        renderCart();
    }
}


function removeFromCart(id) {
    const itemIndex = cart.findIndex(cartItem => cartItem.id === id);
    if (itemIndex !== -1) {
        if (cart[itemIndex].quantity > 1) {
            cart[itemIndex].quantity--;
        } else {
            cart.splice(itemIndex, 1);
        }
        localStorage.setItem("cart", JSON.stringify(cart));
        renderCart();
    }
}


document.getElementById("checkout-form").addEventListener("submit", (e) => {
    e.preventDefault();
    placeOrder();
});



async function clearCart() {
    try {
        const response = await fetch("http://localhost:5133/api/cart/clear", { method: "DELETE" });

        if (response.ok) {
            cart = []; // ✅ Reset the cart
            renderCart(); // ✅ Update UI
            alert("Cart cleared successfully.");
        } else {
            console.error("Failed to clear cart.");
        }
    } catch (error) {
        console.error("Error clearing cart:", error);
    }
}


// ✅ Open the checkout modal
function openCheckoutModal() {
    fetch("http://localhost:5133/api/cart")
        .then(response => response.json())
        .then(cart => {
            if (cart.length === 0) {
                alert("Your cart is empty. Add items to checkout.");
                return;
            }
            document.getElementById("checkout-modal").classList.add("show");
        })
        .catch(error => console.error("Error fetching cart:", error));
}

// ✅ Close the checkout modal
function closeCheckoutModal() {
    document.getElementById("checkout-modal").classList.remove("show");
}

// ✅ Checkout form submission - now saving order in the database
document.getElementById("checkout-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("customer-name").value.trim();
    const phone = document.getElementById("phone-number").value.trim();
    const address = document.getElementById("address").value.trim();

    if (!name || !phone || !address) {
        alert("Please fill in all fields.");
        return;
    }

    try {
        const response = await fetch("http://localhost:5133/api/cart/checkout", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, phone, address })
        });

        if (response.ok) {
            alert("Order placed successfully!");
            renderCart(); // Refresh cart UI
            closeCheckoutModal();
        } else {
            console.error("Failed to place order.");
            alert("Failed to place order.");
        }
    } catch (error) {
        console.error("Error placing order:", error);
    }
});

// ✅ Ensure all buttons are rendered properly
document.querySelectorAll('.btn-category').forEach((btn) => {
    btn.addEventListener('click', (e) => {
        const targetId = btn.getAttribute('onclick').match(/'(.*?)'/)[1];
        scrollToCategory(targetId);
    });
});

document.getElementById('search-bar').addEventListener('input', async (e) => {
    const query = e.target.value.toLowerCase();
    const menuContainer = document.getElementById("menu-container");

    try {
        const response = await fetch(http://localhost:5133/api/menu/search?query=${query});
      if (!response.ok) throw new Error(HTTP error! Status: ${ response.status });

        const filteredData = await response.json();
        renderMenu(filteredData);
    } catch (error) {
        console.error("❌ Error fetching search results:", error);
        menuContainer.innerHTML = "<p class='text-danger'>Failed to load menu items. Please try again.</p>";
    }
});


// ✅ Sort functionality (fetching sorted menu from backend)
document.getElementById('sort-options').addEventListener('change', async (e) => {
    const sortOrder = e.target.value;

    try {
        const response = await fetch(http://localhost:5133/api/menu/sort?order=${sortOrder});
      const sortedMenu = await response.json();
        renderMenu(sortedMenu);
    } catch (error) {
        console.error("Error sorting menu:", error);
    }
});

document.getElementById('theme-toggle')?.addEventListener('click', () => {
    document.body.classList.toggle('light-theme');

    fetch("http://localhost:5133/api/user/theme", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            theme: document.body.classList.contains("light-theme") ? "light" : "dark"
        })
    })
        .catch(error => console.error("❌ Error saving theme preference:", error));
});


// document.addEventListener('DOMContentLoaded', () => {
//   initializeMenu();
//   const savedTheme = localStorage.getItem('theme');
//   if (savedTheme === 'light') document.body.classList.add('light-theme');
// });

// let cart = [];

// function initializeMenu() {
//   const menuData = getDefaultMenuData();
//   renderMenu(menuData);
// }

// function renderMenu(menuData) {
//   const menuContainer = document.getElementById('menu-container');
//   menuContainer.innerHTML = ''; // Clear existing menu

//   for (const category in menuData) {
//       const categoryDiv = document.createElement('div');
//       categoryDiv.classList.add('menu-category');
//       categoryDiv.id = category;

//       categoryDiv.innerHTML = <h2>${category.toUpperCase()}</h2>;

//       menuData[category].forEach(item => {
//           const itemDiv = document.createElement('div');
//           itemDiv.classList.add('menu-item');
//           itemDiv.innerHTML = `
//           <img src="${item.image}" alt="${item.name}">
//           <div class="description">
//               <h4>${item.name}</h4>
//               <p>${item.description}</p>
//           </div>
//           <div class="price">$${item.price.toFixed(2)}</div>
//           <button class="btn btn-primary" onclick="handleAddToCart('${item.name}', ${item.price})">Add to Cart</button>`;
//           categoryDiv.appendChild(itemDiv);
//       });

//       menuContainer.appendChild(categoryDiv);
//   }
// }



// function addToCart(name, price) {
//   const existingItem = cart.find(item => item.name === name);
//   if (existingItem) {
//       existingItem.quantity++;
//   } else {
//       cart.push({ name, price, quantity: 1 });
//   }
//   renderCart();
// }

// function renderCart() {
//   const cartItems = document.getElementById('cart-items');
//   cartItems.innerHTML = cart.map(item => `
//       <li class="list-group-item d-flex justify-content-between align-items-center">
//           ${item.name} x${item.quantity}
//           <span class="badge bg-primary">$${(item.price * item.quantity).toFixed(2)}</span>
//       </li>
//   `).join('');

//   const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
//   document.getElementById('total-price').textContent = Total: $${totalPrice.toFixed(2)};
// }

// function clearCart() {
//   cart = [];
//   renderCart();
// }

// // Search functionality
// document.getElementById('search-bar').addEventListener('input', (e) => {
//   const query = e.target.value.toLowerCase();
//   const menuData = JSON.parse(localStorage.getItem('menuData')) || getDefaultMenuData();
//   const filteredData = {};

//   // Filter menu items based on the search query
//   for (const category in menuData) {
//       filteredData[category] = menuData[category].filter(item =>
//           item.name.toLowerCase().includes(query) ||
//           item.description.toLowerCase().includes(query)
//       );
//   }

//   renderMenu(filteredData);
// });


// // Sort functionality
// document.getElementById('sort-options').addEventListener('change', (e) => {
//   const sortOrder = e.target.value;
//   const menuData = JSON.parse(localStorage.getItem('menuData')) || getDefaultMenuData();

//   if (sortOrder === 'low-to-high' || sortOrder === 'high-to-low') {
//       for (const category in menuData) {
//           menuData[category].sort((a, b) =>
//               sortOrder === 'low-to-high' ? a.price - b.price : b.price - a.price
//           );
//       }
//   }

//   renderMenu(menuData);
// });

// // Scroll to category functionality
// function scrollToCategory(id) {
//   const element = document.getElementById(id);
//   const rightPart = document.querySelector('.right-part');

//   if (element && rightPart) {
//       const offsetTop = element.offsetTop - rightPart.offsetTop;
//       rightPart.scrollTo({
//           top: offsetTop,
//           behavior: 'smooth'
//       });
//   }

//   // Highlight active button
//   document.querySelectorAll('.btn-category').forEach(btn => btn.classList.remove('active'));
//   document.querySelector([onclick="scrollToCategory('${id}')"]).classList.add('active');
// }

// function getDefaultMenuData() {
//   return {
//       maki: [
//           {
//               name: 'Spicy Tuna Maki',
//               description: 'A tantalizing blend of spicy tuna, cucumber, and avocado, harmoniously rolled in nori and seasoned rice.',
//               price: 5,
//               image: 'images/sushi1.png',
//           },
//           {
//               name: 'Mango Maki',
//               description: 'Tempura-fried shrimp, cucumber, and cream cheese embrace a center of fresh avocado.',
//               price: 5,
//               image: 'images/sushi2.png',
//           },
//       ],
//       uramaki: [
//           {
//               name: 'Volcano Delight',
//               description: 'Creamy crab salad, avocado, and cucumber rolled inside, topped with spicy tuna and drizzled with fiery sriracha sauce.',
//               price: 12,
//               image: 'images/sushi5.png',
//           },
//       ],
//       specialRolls: [
//           {
//               name: 'Sunrise Bliss',
//               description: 'A delicate combination of fresh salmon, cream cheese, and asparagus, rolled in orange-hued tobiko.',
//               price: 16,
//               image: 'images/sushi12.png',
//           },
//       ],
//   };
// }


// // Theme toggle functionality
// document.getElementById('theme-toggle').addEventListener('click', () => {
//   document.body.classList.toggle('light-theme');
//   localStorage.setItem('theme', document.body.classList.contains('light-theme') ? 'light' : 'dark');
// });

// // Lazy load menu category visibility
// document.addEventListener('scroll', () => {
//   const categories = document.querySelectorAll('.menu-category');
//   categories.forEach(category => {
//       const rect = category.getBoundingClientRect();
//       if (rect.top < window.innerHeight && rect.bottom > 0) {
//           category.classList.add('visible');
//       } else {
//           category.classList.remove('visible');
//       }
//   });
// });

// // Cart functionality
// function addToCart(item) {
//   cart.push(item);
//   renderCart();
// }

// function renderCart() {
//   const cartItems = document.getElementById('cart-items');
//   cartItems.innerHTML = cart.map(item => <li>${item.name} - $${item.price}</li>).join('');

//   const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);
//   document.getElementById('total-price').textContent = Total: $${totalPrice.toFixed(2)};
// }

// function handleAddToCart(name, price) {
//   const role = localStorage.getItem("role");
//   if (!role || role === "guest") {
//       alert("Please login to add items to your cart!");
//       window.location.href = "login.html";
//       return;
//   }

//   // If logged in as customer or admin, add to cart
//   addToCart(name, price);
// }