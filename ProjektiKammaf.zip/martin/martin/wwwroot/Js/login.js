document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");

    // Handle form submission
    loginForm.addEventListener("submit", (e) => {
        e.preventDefault();
        handleLogin();
    });
});

function handleLogin() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    // Simulated credentials (Admin & Customer)
    const adminCredentials = { username: "admin", password: "admin123" };
    const customerCredentials = { username: "customer", password: "customer123" };

    if (username === adminCredentials.username && password === adminCredentials.password) {
        // Login as admin
        localStorage.setItem("role", "admin");
        alert("Logged in as Admin!");
        window.location.href = "admin.html"; // Redirect to admin page
    } else if (username === customerCredentials.username && password === customerCredentials.password) {
        // Login as customer
        localStorage.setItem("role", "customer");
        alert("Logged in as Customer!");
        window.location.href = "menu.html"; // Redirect to menu page
    } else {
        // Invalid login
        alert("Invalid username or password!");
    }
}
