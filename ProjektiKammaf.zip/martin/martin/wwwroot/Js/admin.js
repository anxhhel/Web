﻿document.addEventListener("DOMContentLoaded", async () => {
    const role = await checkUserRole();
    if (role !== "admin") {
        alert("Access denied! Only admins can access this page.");
        window.location.href = "login.html";
    }

    await updateRevenueTable();
    await renderMenuItems();
    await renderChart();
    await renderOrders();
    await calculateTotalRevenue();
    await renderRevenueBreakdown();
});

const logoutButton = document.getElementById("logout-btn");
if (logoutButton) {
    logoutButton.addEventListener("click", logout);
}

async function checkUserRole() {
    try {
        const response = await fetch("http://localhost:5133/api/auth/role", {
            method: "GET",
            credentials: "include"
        });
        const data = await response.json();
        return data.role;
    } catch (error) {
        console.error("Error checking role:", error);
        return null;
    }
}


function logout() {
    fetch("http://localhost:5133/api/auth/logout", { method: "POST", credentials: "include" })
        .then(() => window.location.href = "login.html")
        .catch(error => console.error("Logout failed:", error));
}

document.getElementById("logout-btn")?.addEventListener("click", logout);

// ✅ Initialize Chart
let chartInstance;

// ✅ Fetch orders from the backend
async function fetchOrders() {
    try {
        const response = await fetch("http://localhost:5133/api/orders");
        if (!response.ok) throw new Error("Failed to fetch orders");
        return await response.json();
    } catch (error) {
        console.error("Error fetching orders:", error);
        return [];
    }
}

// ✅ Render Revenue Chart (Now Uses API Data)
async function renderChart() {
    const ctx = document.getElementById("salesChart").getContext("2d");
    const menuData = await fetchMenuData();
    const labels = [];
    const data = [];
    const categoryColors = {
        maki: "#FF6384",
        uramaki: "#36A2EB",
        "special rolls": "#FFCE56",
        other: "#9966FF", // Default color for unlisted categories
    };

    let totalItems = 0;

    Object.keys(menuData).forEach((category) => {
        const categoryCount = menuData[category].length || 0;
        if (categoryCount > 0) {
            labels.push(category.charAt(0).toUpperCase() + category.slice(1));
            data.push(categoryCount);
            totalItems += categoryCount;
        }
    });

    if (totalItems === 0) {
        Object.keys(categoryColors).forEach((category) => {
            if (category !== "other") {
                labels.push(category.charAt(0).toUpperCase() + category.slice(1));
                data.push(1);
            }
        });
    }

    const backgroundColors = labels.map(label => categoryColors[label.toLowerCase()] || categoryColors.other);

    if (chartInstance) {
        chartInstance.destroy();
    }

    chartInstance = new Chart(ctx, {
        type: "pie",
        data: {
            labels,
            datasets: [{ data, backgroundColor: backgroundColors }],
        },
        options: {
            responsive: false,
            plugins: {
                legend: { display: true, position: "bottom" },
                tooltip: {
                    callbacks: {
                        label: function (tooltipItem) {
                            const category = labels[tooltipItem.dataIndex];
                            const count = data[tooltipItem.dataIndex];
                            const percentage = ((count / totalItems) * 100).toFixed(2);
                            return ${ category }: ${ count } (${ percentage }%);
}
                    }
                }
            },
        },
    });

ctx.canvas.parentNode.style.width = "300px";
ctx.canvas.parentNode.style.height = "300px";
}

async function renderRevenue() {
    try {
        const response = await fetch("http://localhost:5133/api/revenue");
        const { totalRevenue } = await response.json();
        document.getElementById("total-revenue").textContent = $${ totalRevenue.toFixed(2) };
    } catch (error) {
        console.error("Error fetching revenue:", error);
    }
}

async function fetchTotalRevenue() {
    try {
        const response = await fetch("http://localhost:5133/api/revenue");
        if (!response.ok) throw new Error("Failed to fetch total revenue");

        const { totalRevenue } = await response.json();
        return totalRevenue;
    } catch (error) {
        console.error("Error fetching total revenue:", error);
        return 0;
    }
}

async function fetchMenuData() {
    try {
        const response = await fetch("http://localhost:5133/api/menu");
        return await response.json();
    } catch (error) {
        console.error("Error fetching menu data:", error);
        return {};
    }
}


// ✅ Add Menu Item
async function addMenuItem() {
    const formData = new FormData(document.getElementById("menu-item-form"));

    try {
        const response = await fetch("http://localhost:5133/api/menu", { method: "POST", body: formData });
        if (response.ok) {
            alert("Menu item added successfully!");
            await renderMenuItems();  // ✅ Update Menu
        } else {
            alert("Failed to add menu item.");
        }
    } catch (error) {
        console.error("Error adding menu item:", error);
    }
}


async function renderRevenueBreakdown() {
    try {
        const revenueBreakdown = await fetchRevenueBreakdown();
        const revenueBreakdownContainer = document.getElementById("revenue-breakdown");
        revenueBreakdownContainer.innerHTML = "";

        revenueBreakdown.forEach(({ category, sold, revenue }) => {
            revenueBreakdownContainer.innerHTML += `
                <tr>
                    <td>${category.charAt(0).toUpperCase() + category.slice(1)}</td>
                    <td>${sold}</td>
                    <td>$${revenue.toFixed(2)}</td>
                </tr>
            `;
        });

        if (revenueBreakdownContainer.innerHTML === "") {
            revenueBreakdownContainer.innerHTML = `
                <tr>
                    <td colspan="3" class="text-center">No data available</td>
                </tr>
            `;
        }
    } catch (error) {
        console.error("Error rendering revenue breakdown:", error);
    }
}


// ✅ Edit Menu Item
async function editMenuItem(itemId) {
    try {
        const response = await fetch(http://localhost:5133/api/menu/${itemId});
        const item = await response.json();

        document.getElementById("menu-item-name").value = item.name;
        document.getElementById("menu-item-description").value = item.description;
        document.getElementById("menu-item-price").value = item.price;

        document.getElementById("menu-item-form").setAttribute("data-id", itemId);
    } catch (error) {
        console.error("Error fetching menu item:", error);
    }
}

// ✅ Delete Menu Item
async function deleteMenuItem(itemId) {
    try {
        await fetch(http://localhost:5133/api/menu/${itemId}, { method: "DELETE" });
            renderMenuItems();
    } catch (error) {
        console.error("Error deleting menu item:", error);
    }
}

async function renderMenuItems() {
    const menuData = await fetchMenuData();
    const menuItemsContainer = document.getElementById("menu-items");
    menuItemsContainer.innerHTML = "";

    Object.entries(menuData).forEach(([category, items]) => {
        items.forEach((item, index) => {
            menuItemsContainer.innerHTML += `
                <tr>
                    <td>${item.id}</td>
                    <td><img src="${item.image}" alt="${item.name}" style="width: 50px; height: 50px;"></td>
                    <td>${category}</td>
                    <td>${item.name}</td>
                    <td>${item.description}</td>
                    <td>$${item.price.toFixed(2)}</td>
                    <td>${item.sold || 0}</td>
                    <td>
                        <button class="btn btn-warning" onclick="editMenuItem('${item.id}')">Edit</button>
                        <button class="btn btn-danger" onclick="deleteMenuItem('${item.id}')">Delete</button>
                    </td>
                </tr>`;
        });
    });
}

async function renderOrders() {
    try {
        const orders = await fetchOrders();
        const orderContainer = document.getElementById("order-container");
        orderContainer.innerHTML = "";

        orders.forEach(order => {
            orderContainer.innerHTML += `
                <div class="order-box">
                    <h4>Order #${order.id}</h4>
                    <p><strong>Name:</strong> ${order.name}</p>
                    <p><strong>Phone:</strong> ${order.phone}</p>
                    <p><strong>Address:</strong> ${order.address}</p>
                    <ul>${order.items.map(item => <li>${item.name} x${item.quantity} - $${item.price.toFixed(2)}</li>).join("")}</ul>
                    <p><strong>Total:</strong> $${order.total.toFixed(2)}</p>
                    <p><strong>Status:</strong> ${order.status}</p>
                    <button class="btn btn-success" onclick="updateOrderStatus('${order.id}', 'Completed')">Mark as Completed</button>
                    <button class="btn btn-danger" onclick="deleteOrder('${order.id}')">Delete</button>
                </div>`;
        });

    } catch (error) {
        console.error("Error rendering orders:", error);
    }
}



// ✅ Mark Order as Completed
async function markOrderCompleted(orderId) {
    try {
        const response = await fetch(http://localhost:5133/api/orders/${orderId}/complete, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
        });

    if (response.ok) {
        alert("Order marked as completed!");
        await renderOrders();
        await updateRevenueTable();  // ✅ Ensure Revenue is Updated
    } else {
        alert("Failed to complete the order.");
    }
} catch (error) {
    console.error("Error completing order:", error);
}
}


async function fetchRevenueBreakdown() {
    try {
        const response = await fetch("http://localhost:5133/api/revenue/breakdown");
        if (!response.ok) throw new Error("Failed to fetch revenue breakdown");

        return await response.json();
    } catch (error) {
        console.error("Error fetching revenue breakdown:", error);
        return [];
    }
}


// ✅ Delete an Order
async function deleteOrder(orderId) {
    try {
        const response = await fetch(http://localhost:5133/api/orders/${orderId}, { method: "DELETE" });

        if (response.ok) {
            alert("Order deleted successfully!");
            await renderOrders();
            await updateRevenueTable();
        } else {
            alert("Failed to delete order.");
        }
    } catch (error) {
        console.error("Error deleting order:", error);
    }
}


// ✅ Update Revenue Table
async function updateRevenueTable() {
    try {
        const response = await fetch("http://localhost:5133/api/revenue");
        const revenueData = await response.json();

        document.getElementById("total-revenue").textContent = $${ revenueData.total.toFixed(2) };

        const revenueTable = document.getElementById("revenue-table-body");
        revenueTable.innerHTML = revenueData.categories.map(cat => `
            <tr>
                <td>${cat.name}</td>
                <td>${cat.itemsSold}</td>
                <td>$${cat.revenue.toFixed(2)}</td>
            </tr>
        `).join("");

        // ✅ Update Revenue Breakdown
        await renderRevenueBreakdown();

    } catch (error) {
        console.error("Error updating revenue table:", error);
    }
}


// ✅ Place an Order
async function placeOrder() {
    try {
        const cartResponse = await fetch("http://localhost:5133/api/cart");
        const cart = await cartResponse.json();

        if (!cart || cart.length === 0) {
            alert("Your cart is empty. Add items to checkout.");
            return;
        }

        const name = document.getElementById("customer-name").value.trim();
        const phone = document.getElementById("phone-number").value.trim();
        const address = document.getElementById("address").value.trim();

        if (!name || !phone || !address) {
            alert("Please fill in all fields.");
            return;
        }

        const order = { name, phone, address, items: cart };
        const response = await fetch("http://localhost:5133/api/orders", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(order),
        });

        if (response.ok) {
            alert("Order placed successfully!");
            await renderOrders();
        } else {
            alert("Failed to place order.");
        }
    } catch (error) {
        console.error("Error placing order:", error);
    }
}



// ✅ Update Order Status
async function updateOrderStatus(orderId, newStatus) {
    try {
        const response = await fetch(http://localhost:5133/api/orders/${orderId}/status, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: newStatus }),
        });

    if (response.ok) {
        alert(Order status updated to ${ newStatus });
        renderOrders();
    } else {
        alert("Failed to update order status.");
    }
} catch (error) {
    console.error("Error updating order status:", error);
}
}