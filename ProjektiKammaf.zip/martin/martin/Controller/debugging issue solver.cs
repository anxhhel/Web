Add-Migration <migrationName> 
Update-Database
