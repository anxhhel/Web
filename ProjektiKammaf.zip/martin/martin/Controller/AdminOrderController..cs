@model List<SushiRestaurant.Models.Order>

<h2>Manage Orders</h2>
<table>
    <thead>
        <tr>
            <th>Order ID</th>
            <th>User</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach (var order in Model)
        {
            <tr>
                <td>@order.OrderID</td>
                <td>@order.UserID</td>
                <td>@order.OrderDate</td>
                <td>@order.Status</td>
                <td>
                    <form asp-action="UpdateStatus" method="post">
                        <input type="hidden" name="orderId" value="@order.OrderID" />
                        <select name="status">
                            <option value="Pending" @(order.Status == "Pending" ? "selected" : "")>Pending</option>
                            <option value="Confirmed" @(order.Status == "Confirmed" ? "selected" : "")>Confirmed</option>
                            <option value="Delivered" @(order.Status == "Delivered" ? "selected" : "")>Delivered</option>
                        </select>
                        <button type="submit">Update</button>
                    </form>
                </td>
            </tr>
        }
    </tbody>
</table>
