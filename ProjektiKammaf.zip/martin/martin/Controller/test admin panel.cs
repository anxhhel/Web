[HttpPost]
public IActionResult AddMenuItem(MenuItem model)
{
    if (ModelState.IsValid)
    {
        _context.MenuItems.Add(model);
        _context.SaveChanges();
        return RedirectToAction("Menu");
    }
    return View(model);
}
