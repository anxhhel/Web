Add-Migration InitialCreate  // This will create a new migration file
Update-Database              // This applies the migration to create the database and tables
