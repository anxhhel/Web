public IActionResult Index()
{
    var menuItems = _context.MenuItems.ToList();  // Fetch all menu items from the database
    return View(menuItems);  // Return the data to the View
}
