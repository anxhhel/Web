Add-Migration InitialCreate   // Create migration for the database schema
Update-Database               // Apply migration and create database
