var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, false);
if (result.Succeeded)
{
    return RedirectToAction("Index", "Home");
}
